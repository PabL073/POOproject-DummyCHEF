#include "document_list_recipes.h"

#include <QtSql>
#include <QSqlError>
#include "iexceptions.h"
#include "bd_exception.h"


QString Document_List_Recipes::Message()
{
QString delim="/";

QString servername ="DESKTOP-V7ILIT2";
QString dbname="DummyChef";
QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");
db.setConnectOptions();
QString dsn = QString ("DRIVER={SQL SERVER};SERVER=%1;DATABASE=%2;Trusted_Connection=Yes;").arg(servername).arg(dbname);
db.setDatabaseName(dsn);
QString message="4";
message.append(delim);
int ok=0;

   if(db.open())
   {
       QSqlQuery qry;
       if(qry.exec("SELECT [Denumire_reteta],[Nume_chef] FROM [DummyChef].[dbo].[Retete]"))
       {
           while(qry.next())
           {
               if(qry.value(this->_col0).toString().contains(_keyword))
               {
                 if(this->_col0==0)
                 {
                 message.append(qry.value(this->_col0).toString());
                 message.append(delim);
                 }
                 message.append(qry.value(this->_col1).toString());
                 message.append(delim);
                 ok=1;
               }
           }

       if(ok==0)
       {
           if(this->_col0==0)
           message.append("nu exista nicio reteta cu denumirea introdusa/");
                   else
               message.append("nu exista acest chef/");
       }

      }
       db.close();
  }
   else
   {
       try
       {
           BD_exception ex;
           throw ex;
       }
       catch(IExceptions &ex)
       {
           //trimit eroarea
       }
   }
return message;
}
