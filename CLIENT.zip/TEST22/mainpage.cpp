#include "mainpage.h"
#include "ui_mainpage.h"
#include "addreteta.h"
#include "firstscreen.h"

mainpage::mainpage(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::mainpage)
{
    ui->setupUi(this);
    QWidget::setWindowTitle("Utilizator CHEF");

//setez scrisul din campul de cautare
    ui->searchBox->setPlaceholderText("Căutați numele rețetei...");

    // setez backgroundul butonului de search
    QPixmap pixmap(":/img/da.jpg");
    QIcon ButtonIcon(pixmap);
    ui->searchButtomn->setIcon(ButtonIcon);
    ui->searchButtomn->setIconSize(ui->searchButtomn->size());

//setez backgroundul butonului de favorite

    QPixmap fav(":/img/favorites.png");
    QIcon FAVbutton(fav);
    ui->favoritesButton->setIcon(FAVbutton);
    ui->favoritesButton->setIconSize(ui->favoritesButton->size());


}

mainpage::~mainpage()
{
    delete ui;
}

void mainpage::on_addReteta_clicked()
{
    addReteta* Query= new addReteta(nullptr);
    Query->show();


}


void mainpage::on_logoutButton_clicked()
{
    delete this;
    FirstScreen *S=new FirstScreen(nullptr);
    S->show();

}


void mainpage::on_searchList_itemClicked(QListWidgetItem *item)
{

}

