#include "tcpclient.h"
#include "QTcpSocket"
#include "QDebug"

bool TCPClient::onSignal =false;
QString TCPClient::readText="";
QTcpSocket* TCPClient::socket=nullptr;
QString TCPClient::username="";
TCPClient* TCPClient::instance=nullptr;
QString TCPClient:: securityQuestion="";



TCPClient::TCPClient(QObject *parent)
    : QObject{parent}
{
    socket = new QTcpSocket(this);
    connect(socket, SIGNAL(readyRead()), this, SLOT(readyRead()));
}

void TCPClient::readyRead()
{
    qDebug() << "Ready to read...";
    QByteArray message;
    message = socket->readAll();

    TCPClient::readText=message;
    TCPClient::onSignal=true;

    if(socket->isWritable())
    {
        //const char* sendMessage = "Hello";
        //socket->write(sendMessage);
        //socket->waitForBytesWritten(1000);
    }
}

void TCPClient::start(QString ip, unsigned short port)
{

    socket->connectToHost(ip, port); // pune ip si port din parametri
    if (socket->waitForConnected(3000))
    {
        qDebug() << "Connected...";
    }
    else
    {
        qDebug() << "Connection to server failed...";
    }

   // QByteArray mesaj ="Salut, Raluca!";
   // socket->write((mesaj));
}

void TCPClient::stop()
{
    if (this->socket->isOpen())
    {
        this->socket->close();
        qDebug() << "Socket closed...";
    }
}

QString TCPClient::send_recieve(QString s)
{
    if (TCPClient::socket->isWritable())
    {
        qDebug()<<"request message:"<<s<<"\n";
        QByteArray serverMessage = s.toUtf8();
        TCPClient::socket->write(serverMessage);
        TCPClient::socket->waitForBytesWritten(100);
    }

    while(TCPClient::onSignal==false)
    {
        TCPClient::socket->waitForReadyRead(100);
    }

    qDebug()<<"recievedMessage:"<<TCPClient::readText<<"\n";
    QString msg=TCPClient::readText;
    TCPClient::onSignal=false;
    readText="";

    return msg;
}

void TCPClient::setUsername(QString s)
{
    username=s;
}

QString TCPClient::getUsername()
{
    return username;
}

void TCPClient::setQuestion(QString s)
{
    securityQuestion=s;
}

QString TCPClient::getQuestion()
{
    return securityQuestion;
}

TCPClient *TCPClient::getInstance()
{
    if (instance == nullptr)
        {
            instance = new TCPClient();
        }

    return instance;
}

