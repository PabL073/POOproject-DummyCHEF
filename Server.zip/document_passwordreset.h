#ifndef DOCUMENT_PASSWORDRESET_H
#define DOCUMENT_PASSWORDRESET_H

#include "idocument.h"

class Document_PasswordReset : public IDocument
{
private:
    QString _username;
    QString _answer;
    QString _newpassword;


public:
    Document_PasswordReset(const QString& username,const QString& answer,const QString& newpassword)
        :_username(username),_answer(answer),_newpassword(newpassword){};
    QString Message();
};

#endif // DOCUMENT_PASSWORDRESET_H
