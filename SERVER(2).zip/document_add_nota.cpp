#include "document_add_nota.h"
#include <QtSql>
#include "iexceptions.h"
#include "bd_exception.h"


QString Document_Add_Nota::Message()
{

    QSqlDatabase db=this->open_DB();
    QString message;

       if(db.open())
       {
           int ok=0;
           message.append("9/");
           QSqlQuery qry;
           if(qry.exec("SELECT * FROM [DummyChef].[dbo].[Retete]"))
           {
               while(qry.next() && ok==0)
               {
                   if(this->_recipe==qry.value(1).toString())
                   {
                       if(this->_chefname==qry.value(2).toString())
                       {
                           float medie=qry.value(7).toDouble();
                           int nr_note=qry.value(8).toInt();
                           medie=medie*nr_note;
                           medie+=this->_nota;
                           nr_note++;
                           medie=medie/nr_note;
                           QSqlQuery uqry;
                           uqry.prepare("UPDATE [DummyChef].[dbo].[Retete] SET [Medie]=:1, [Numar_note]=:2 WHERE [Denumire_reteta]=:3 AND [Nume_chef]=:4");
                           uqry.bindValue(":1",medie);
                           uqry.bindValue(":2",nr_note);
                           uqry.bindValue(":3",this->_recipe);
                           uqry.bindValue(":4",this->_chefname);
                           uqry.exec();
                           if(!uqry.exec())
                           {
                               try
                               {
                                   IExceptions* ex=Factory_Exceptions::Create_Protocol_Exception_Instance();
                                   throw ex;
                               }
                               catch(IExceptions *ex)
                               {
                                   message.append(ex->Message());
                               }
                           }
                           else
                           {
                               message.append("nota adaugata cu succes/");
                               ok=1;
                           }

                       }
                   }
               }
               if(ok==0)
                   message.append("nu exista aceasta reteta/");
           }
           db.close();
       }
       else
       {
           try
           {
               IExceptions* ex=Factory_Exceptions::Create_Protocol_Exception_Instance();
               throw ex;
           }
           catch(IExceptions *ex)
           {
               message.append(ex->Message());
           }
       }

    return message;
}
