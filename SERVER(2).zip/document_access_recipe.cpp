#include "document_access_recipe.h"
#include <QtSql>
#include <QSqlError>
#include "iexceptions.h"
#include "bd_exception.h"
#include <list>

QString Document_Access_Recipe::Message()
{
    QString message;
    if(_contor==0)
   {
        QSqlDatabase db=this->open_DB();
        QString message;
        int ok=0;

       if(db.open())
       {
           message.append("7/");
           QSqlQuery qry;
           if(qry.exec("SELECT * FROM [DummyChef].[dbo].[Retete]"))
           {
               while(qry.next() && ok==0)
               {
                   if(this->_recipe.get_name()==qry.value(1).toString())
                   {
                       if(this->_recipe.get_chefname()==qry.value(2).toString())
                       {
                           this->_recipe.set_ingredients(qry.value(3).toString());
                           this->_recipe.set_steps(qry.value(4).toString());
                           this->_recipe.set_image(qry.value(5).toString());
                           this->_recipe.set_reviews(qry.value(6).toString());
                           this->_recipe.set_nota(qry.value(7).toFloat());
                           ok=1;
                           _contor=1;
                       }
                   }
               }
               if(ok==0)
                   message.append("solicitare inexistenta/");
               else
               {
                  message.append("Detalii reteta:/");
               }
           }
           db.close();
           return message;
       }
       else
       {
           try
           {
               IExceptions *ex=Factory_Exceptions::Create_BD_Exception_Instance();
               throw ex;
           }
           catch(IExceptions &ex)
           {
               message.append(ex.Message());
           }
       }
    }
    if(_contor==1)
    {
        message=this->send_ingredients();
        _contor++;
    }
    else
        if(_contor==2)
        {
            message=this->send_steps();
            _contor++;
        }
    else
            if(_contor==3)
            {
                message=this->send_photo();
                _contor++;
            }
    else
                if(_contor==4)
                {
                    message=this->send_reviews();
                }
    return message;
}

QString Document_Access_Recipe::send_ingredients()
{
    QString delim="/";
    QString message="7";
    message.append(delim);
    message.append("Ingrediente:/");
    std::list<Ingredient>::iterator it;
    for (it = this->_recipe._ingredients.begin(); it != this->_recipe._ingredients.end(); ++it)
                   {
                      message.append(it->get_gramaj());
                      message.append(delim);
                      message.append(it->get_denumire());
                      message.append(delim);
                   }
    return message;
}


QString Document_Access_Recipe::send_steps()
{
    QString delim="/";
    QString message="7";
    message.append(delim);
    message.append("Pasi:/");
    message.append(this->_recipe.get_steps());
    message.append(delim);
    return message;
}


QString Document_Access_Recipe::send_photo()
{
    QString delim="/";
    QString message="7/";
    QString photo=this->_recipe.get_image();

    FILE * pFile;
    long lSize;
    char * buffer;

     pFile = fopen (photo.toStdString().c_str() , "rb" );
     if (pFile==NULL) {fputs ("File error",stderr); exit (1);}

     // obtain file size:
     fseek (pFile , 0 , SEEK_END);
     lSize = ftell (pFile);
     rewind (pFile);

     // allocate memory to contain the whole file:
     buffer = (char*) malloc (sizeof(char)*lSize);
     if (buffer == NULL) {fputs ("Memory error",stderr); exit (2);}

     // copy the file into the buffer:
     fread (buffer,1,lSize,pFile);
     message.append(QString::number(lSize));
     message.append(delim);
     message.append(buffer);

     return message;
}

QString Document_Access_Recipe::send_reviews()
{
    QString delim="/";
    QString message="7";
    message.append(delim);
    message.append("Nota:/");
    QString nota;
    nota.setNum(this->_recipe.get_nota());
    message.append(nota);
    message.append("/");
    message.append("Comentarii:/");
    std::list<Review>::iterator it;
    for (it = this->_recipe._reviews.begin(); it != this->_recipe._reviews.end(); ++it)
                   {
                      message.append(it->get_username());
                      message.append(delim);
                      message.append(it->get_review());
                      message.append(delim);
                   }
    return message;
}

