#ifndef DOCUMENT_H
#define DOCUMENT_H

#include "idocument.h"

class document : public IDocument
{
public:
    virtual QString Message() = 0;
    virtual ~document() {};
    QSqlDatabase open_DB();
};

#endif // DOCUMENT_H
