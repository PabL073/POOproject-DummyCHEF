#include "firstscreen.h"
#include "login.h"
#include <QApplication>
#include "tcpclient.h"

#define ip_server "127.0.0.1"
#define connection_port 1234

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    TCPClient *client=TCPClient::getInstance();
    client->start(ip_server, connection_port);

    FirstScreen w;
    w.show();

    return app.exec();
}
