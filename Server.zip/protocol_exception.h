#ifndef PROTOCOL_EXCEPTION_H
#define PROTOCOL_EXCEPTION_H

#include "exceptions.h"

class Protocol_exception : public Exceptions
{
public:
    Protocol_exception() {this->message="protocol nerecunoscut";}
};

#endif // PROTOCOL_EXCEPTION_H
