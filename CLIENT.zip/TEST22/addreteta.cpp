#include "addreteta.h"
#include "ui_addreteta.h"

addReteta::addReteta(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::addReteta)
{
    ui->setupUi(this);
    QWidget::setWindowTitle("Formular adaugare reteta");
    ui->addNume->setPlaceholderText("ex: Budinca de chia cu capsuni");
    ui->addIngrediente->setPlaceholderText("ex: Seminte chia/Lapte(ml)/Capsuni etc.");
    ui->addGramaje->setPlaceholderText("100/200/80");

}

addReteta::~addReteta()
{
    delete ui;
}

void addReteta::on_OK_accepted()
{

}


void addReteta::on_Cancel_rejected()
{

}

