#include "document_log.h"
#include <QtSql>
#include "iexceptions.h"
#include "bd_exception.h"

QString Document_Log::Message()
{
QSqlDatabase db=this->open_DB();
QString message;

   if(db.open())
   {
       message="0/";
       int ok=0;
       QSqlQuery qry;
       if(qry.exec("SELECT * FROM [DummyChef].[dbo].[Log]"))
       {
           while(qry.next() && ok==0)
           {
               if(this->_username==qry.value(0).toString())
               {
                   if(this->_password==qry.value(1).toString())
                   {
                       message.append("DA/");
                       message.append(qry.value(5).toString());
                       ok=1;
                   }
               }
           }
           if(ok==0)
               message.append(("NU/"));
       }
       else
       {
           try
           {
               IExceptions *ex=Factory_Exceptions::Create_BD_Exception_Instance();
               throw ex;
           }
           catch(IExceptions &ex)
           {
               message.append(ex.Message());
           }
       }
       db.close();
   }
   else
   {
       try
       {
           IExceptions *ex=Factory_Exceptions::Create_BD_Exception_Instance();
           throw ex;
       }
       catch(IExceptions &ex)
       {
           message.append(ex.Message());
       }
   }

return message;
}
