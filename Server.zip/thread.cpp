#include "thread.h"
#include "idocument.h"


Thread::Thread(qintptr ID,QObject *parent)
    : QThread{parent}
{
    this->socketDescriptor=ID;
}

void Thread::run()
{
    // thread starts here
       qDebug() <<socketDescriptor<< " Thread started";

       socket = new QTcpSocket();

       // set the ID
       if(!socket->setSocketDescriptor(this->socketDescriptor))
       {
           // something's wrong, we just emit a signal
           emit error(socket->error());
           return;
       }

       // connect socket and signal
       // note - Qt::DirectConnection is used because it's multithreaded
       //        This makes the slot to be invoked immediately, when the signal is emitted.

       connect(socket, SIGNAL(readyRead()), this, SLOT(readyRead()), Qt::DirectConnection);
       connect(socket, SIGNAL(disconnected()), this, SLOT(disconnected()),Qt::DirectConnection);


       // We'll have multiple clients, we want to know which is whichc
       qDebug() << socketDescriptor << " Client connected";

       // make this thread a loop,
       // thread will stay alive so that signal/slot to function properly
       // not dropped out in the middle when thread dies

       exec();
}

void Thread::readyRead()
{

    QByteArray Data = socket->readAll();

    qDebug() << socketDescriptor<< "Data in: " << Data;

    QString str;
    str=QString(Data);
    QString index=str[0];
    int prot;
    prot=index.toInt();
    index="/";
    IDocument * pdocument;
    QString send;

    switch(prot)
    {
    case(LOGARE):
    {
        QString username=str.section(index,1,1);
        QString password=str.section(index,2,2);
        pdocument = Factory_Document::Create_LogInstance(username, password);
        send=pdocument->Message();
        qDebug()<<send;
        break;
    }
    case(VERIF_USER_UNIC):
    {
        QString username=str.section(index,1,1);
        pdocument = Factory_Document::Create_UniqueUserInstance(username);
        send=pdocument->Message();
        qDebug()<<send;
        break;
    }
    case(REGISTER):
    {
        QString lastname=str.section(index,1,1);
        QString firstname=str.section(index,2,2);
        QString email=str.section(index,3,3);
        QString username=str.section(index,4,4);
        QString password=str.section(index,5,5);
        QString account=str.section(index,6,6);
        QString answer=str.section(index,7,7);
        pdocument = Factory_Document::Create_RegisterInstance(lastname,firstname,email,username,password,account,answer);
        send=pdocument->Message();
        qDebug()<<send;
        break;
    }
    case(PASSWORD_RESET):
    {
        QString username=str.section(index,1,1);
        QString answer=str.section(index,2,2);
        QString newpassword=str.section(index,3,3);
        pdocument = Factory_Document::Create_PasswordResetInstance(username,answer,newpassword);
        send=pdocument->Message();
        qDebug()<<send;
        break;
    }
    case(LISTA_DENUMIRI_RETETE):
    {
        QString keyword=str.section(index,1,1);
        pdocument = Factory_Document::Create_ListRecipesInstance(keyword,0,1);
        send=pdocument->Message();
        qDebug()<<send;
        break;
    }
    case(LISTA_RETETE_CHEFI):
    {
        QString keyword=str.section(index,1,1);
        pdocument = Factory_Document::Create_ListRecipesInstance(keyword,1,0);
        send=pdocument->Message();
        qDebug()<<send;
        break;
    }
    default:
        break;
    }
    print();


    //socket->close();
}
void Thread::print()
{
    QByteArray mesaj;
    QString send="hello Paul";
    mesaj=send.toUtf8();
    socket->write(mesaj);
    socket->flush();
    socket->waitForBytesWritten(3000);
}

void Thread:: disconnected()
{
    qDebug() << socketDescriptor<< "Disconnected: ";

    socket->deleteLater();
    exit(0);

}
