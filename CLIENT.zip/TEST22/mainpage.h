#ifndef MAINPAGE_H
#define MAINPAGE_H

#include <QMainWindow>
#include <QListWidgetItem>

namespace Ui {
class mainpage;
}

class mainpage : public QMainWindow
{
    Q_OBJECT

public:
    explicit mainpage(QWidget *parent = nullptr);
    ~mainpage();

private slots:
    void on_addReteta_clicked();

    void on_backButton_clicked();

    void on_logoutButton_clicked();

    void on_searchList_itemClicked(QListWidgetItem *item);

private:
    Ui::mainpage *ui;
};

#endif // MAINPAGE_H
