#include <QCoreApplication>
#include <QTcpServer>
#include <QThread>
#include<iostream>
#include <QtSql>
#include <QSqlError>
#include "server.h"
#include"idocument.h"

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    Server myServer;
    myServer.StartServer();


    /*FILE * pFile;
     long lSize;
     char * buffer;
     size_t result;

     pFile = fopen ( "C:\\Poze\\musaca-de-legume.jpg" , "rb" );
     if (pFile==NULL) {fputs ("File error",stderr); exit (1);}

     // obtain file size:
     fseek (pFile , 0 , SEEK_END);
     lSize = ftell (pFile);
     rewind (pFile);

     // allocate memory to contain the whole file:
     buffer = (char*) malloc (sizeof(char)*lSize);
     if (buffer == NULL) {fputs ("Memory error",stderr); exit (2);}

     // copy the file into the buffer:
     result = fread (buffer,1,lSize,pFile);


     /* the whole file is now loaded in the memory buffer. */


     /*FILE * pFileOUT;
       pFileOUT = fopen ("C:\\myfile.jpg", "wb");
       fwrite (buffer , sizeof(char), sizeof(buffer),pFileOUT);
       fclose (pFile);
*/


    return a.exec();
}
