#ifndef IDOCUMENT_H
#define IDOCUMENT_H
#include <QObject>
#include "iexceptions.h"
#include "protocol_exception.h"

typedef enum{LOGARE,VERIF_USER_UNIC,REGISTER,PASSWORD_RESET,LISTA_DENUMIRI_RETETE,LISTA_RETETE_CHEFI} prot;

class IDocument
{
public:

    virtual QString Message() = 0;
    virtual ~IDocument() {};

};

class Factory_Document
{
public:
    static IDocument* Create_LogInstance(const QString &username, const QString &password);
    static IDocument* Create_UniqueUserInstance(const QString& username);
    static IDocument* Create_RegisterInstance(const QString& lastname,const QString& firstname,const QString& email, const QString& username,const QString& password,const QString& account,const QString& answer);
    static IDocument* Create_PasswordResetInstance(const QString& username,const QString& answer,const QString& newpassword);
    static IDocument* Create_ListRecipesInstance(const QString& keyword,int col0, int col1);
};



#endif // IDOCUMENT_H
