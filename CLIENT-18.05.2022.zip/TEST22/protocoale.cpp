#include "protocoale.h"
#include "ui_login.h"
#include "login.h"

protocoale::protocoale()
{
    this->message="";
}

protocoale::~protocoale()
{
    this->message="";
}

QString protocoale::login_protocol()
{
    //"0/"+->text()+'/'+ui->lineEdit_2->text();
}
