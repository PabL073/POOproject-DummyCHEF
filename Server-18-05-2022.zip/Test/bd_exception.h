#ifndef BD_EXCEPTION_H
#define BD_EXCEPTION_H

#include "exceptions.h"

class BD_exception : public Exceptions
{
public:
    BD_exception(){this->message="11111";};
};

#endif // BD_EXCEPTION_H
