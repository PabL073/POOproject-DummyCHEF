#include <QCoreApplication>
#include <QTcpServer>
#include <QThread>
#include<iostream>
#include <QtSql>
#include <QSqlError>
#include "server.h"
#include"idocument.h"

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    Server myServer;
    myServer.StartServer();

    /*FILE * pFile;
     long lSize;
     char * buffer;
     size_t result;

     pFile = fopen ( "C:\\Poze\\musaca-de-legume.jpg" , "rb" );
     if (pFile==NULL) {fputs ("File error",stderr); exit (1);}

     // obtain file size:
     fseek (pFile , 0 , SEEK_END);
     lSize = ftell (pFile);
     rewind (pFile);

     // allocate memory to contain the whole file:
     buffer = (char*) malloc (sizeof(char)*lSize);
     if (buffer == NULL) {fputs ("Memory error",stderr); exit (2);}

     // copy the file into the buffer:
     result = fread (buffer,1,lSize,pFile);


     /* the whole file is now loaded in the memory buffer. */


     /*FILE * pFileOUT;
       pFileOUT = fopen ("C:\\myfile.jpg", "wb");
       fwrite (buffer , sizeof(char), sizeof(buffer),pFileOUT);
       fclose (pFile);
*/


    /*QString str="17/popescu/";
    int nr=str.count('/');
    int prot=str.section("/",0,0).toInt();
    IDocument *pdocument;
    QString send;
    QString delim="/";

    switch(prot)
    {

    case(RETETE_CONT_CHEF):
    {
        if(nr==2)
        {
        pdocument = Factory_Document::Create_SendNameInstance(str.section('/',1,1));
        send=pdocument->Message();
        pdocument=Factory_Document::Create_ListRecipesInstance(send,1,0);
        send=pdocument->Message();
        send.erase(send.begin(),send.begin()+1);
        str="17";
        str+=send;
        send=str;
        }
        else
        {
            try
            {
                IExceptions* ex=Factory_Exceptions::Create_Protocol_Exception_Instance();
                throw ex;
            }
            catch(IExceptions *ex)
            {
                send.append(ex->Message());
            }
        }
        break;
    }
    }
    qDebug()<<send;*/

    return a.exec();
}
