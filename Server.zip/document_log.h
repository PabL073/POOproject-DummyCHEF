#ifndef DOCUMENT_LOG_H
#define DOCUMENT_LOG_H

#include "idocument.h"

class Document_Log : public IDocument
{
private:
    QString _username;
    QString _password;
public:
    Document_Log(QString username, QString password) :_username(username), _password(password) {};
    QString Message();
};

#endif // DOCUMENT_LOG_H
