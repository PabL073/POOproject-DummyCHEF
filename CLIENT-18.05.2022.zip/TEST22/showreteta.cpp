#include "showreteta.h"
#include "ui_showreteta.h"
#include "tcpclient.h"
#include"login.h"
#include <QMessageBox>

showReteta::showReteta(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::showReteta)
{
    ui->setupUi(this);
    ui->reviewTEXT->setPlaceholderText("Scrieti un review...");
     ui->addReview->setDisabled(true);
}

showReteta::~showReteta()
{
    delete ui;
}

void showReteta::completeTitlu(QString s)
{
    ui->Titlu->setText("CHEF: "+s+" \t\t");
}

void showReteta::completeIngrediente(QStringList s)
{
    for(int i=0;i<s.size();i+=2)
    {
        ui->ListaIngrediente->append(s[i]+"\t"+s[i+1]);
    }
}

void showReteta::completeDescriere(QString s)
{
    ui->Descriere->setText(s);
}

void showReteta::completeNota(QString s)
{
    ui->Nota->setText("NOTA:\n"+s);
}

void showReteta::completeRecenzii(QStringList s)
{
    for(int i=0;i<s.size();i+=2)
    {
        ui->Recenzii->append(s[i]+" :"+"  "+s[i+1]);
    }
}

void showReteta::on_pushButton_clicked()
{
    QString send="12/"+Login::username+'/';
    QString aux1=TCPClient::send_recieve("16/"+Login::username+'/');
    QStringList NumeChef=aux1.split('/');
    QString aux=ui->Titlu->text();
    QStringList numeReteta=aux.split("\t");

    QString nume_RETETA=numeReteta[5];

    send+=nume_RETETA+'/'+NumeChef[1]+'/';
    QString msg=TCPClient::send_recieve(send);

    QMessageBox addFAV;

    if(msg.contains("DA"))
    {
         addFAV.setText("\n\tReteta adaugata la favorite!\t\n");
    }
    else
    {
        addFAV.setText("\n\tReteta este deja in lista de favorite!\t\n");
    }
    addFAV.exec();

}


void showReteta::on_addNota_editingFinished()
{
    QString sendNota="9/";
    QString aux=ui->Titlu->text();
    QStringList numeReteta=aux.split("\t");

    QString nume_RETETA=numeReteta[5];

    //sendNota+=nume_RETETA+'/';


    QString numeChef =numeReteta[0];
    numeChef.erase(numeChef.begin(),numeChef.begin()+6);

    sendNota+=numeChef+'/'+nume_RETETA+'/'+ui->addNota->text()+'/';

    QString ans=TCPClient::send_recieve(sendNota);

    if(ui->reviewTEXT->toPlainText().isEmpty())
    {
        ui->addReview->setDisabled(true);
    }


    if(ans.contains("succes"))
    {
        QMessageBox addNOTA;
        addNOTA.setText("\n\Ati adaugat o nota pentru reteta!\t\n");
    }

}


void showReteta::on_addReview_clicked()
{

    QString sendReview="8/";
    QString aux=ui->Titlu->text();
    QStringList numeReteta=aux.split("\t");

    QString nume_RETETA=numeReteta[5];

    //sendNota+=nume_RETETA+'/';


    QString numeChef =numeReteta[0];
    numeChef.erase(numeChef.begin(),numeChef.begin()+6);



    sendReview+=numeChef+'/'+nume_RETETA+'/'+Login::username+'/'+ui->reviewTEXT->toPlainText()+'/';

    //8/numereteta/numechef/username/review

    QString ans=TCPClient::send_recieve(sendReview);


    if(ans.contains("succes"))
    {
        QMessageBox addNOTA;
        addNOTA.setText("\n\Ati adaugat un review pentru reteta!\t\n");
    }


}


void showReteta::on_reviewTEXT_textChanged()
{
    if(ui->reviewTEXT->toPlainText().isEmpty()==false)
    {
        ui->addReview->setDisabled(false);
    }
}

