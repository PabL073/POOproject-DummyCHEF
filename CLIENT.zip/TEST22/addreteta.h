#ifndef ADDRETETA_H
#define ADDRETETA_H

#include <QDialog>

namespace Ui {
class addReteta;
}

class addReteta : public QDialog
{
    Q_OBJECT

public:
    explicit addReteta(QWidget *parent = nullptr);
    ~addReteta();

private slots:
    void on_OK_accepted();

    void on_Cancel_rejected();

private:
    Ui::addReteta *ui;
};

#endif // ADDRETETA_H
