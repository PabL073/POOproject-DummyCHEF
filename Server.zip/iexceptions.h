#ifndef IEXCEPTIONS_H
#define IEXCEPTIONS_H
#include <QDebug>


class IExceptions
{
public:
    IExceptions() {};
    virtual QString Message()=0;
};

#endif // IEXCEPTIONS_H
