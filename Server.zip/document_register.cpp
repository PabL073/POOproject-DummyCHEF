#include "document_register.h"
#include <QtSql>
#include "iexceptions.h"
#include "bd_exception.h"

QString Document_Register::Message()
{
QString delim="/";

QString servername ="DESKTOP-V7ILIT2";
QString dbname="DummyChef";
QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");
db.setConnectOptions();
QString dsn = QString ("DRIVER={SQL SERVER};SERVER=%1;DATABASE=%2;Trusted_Connection=Yes;").arg(servername).arg(dbname);
db.setDatabaseName(dsn);
QString message="2";
message.append(delim);

   if(db.open())
   {
       QString sqry="INSERT INTO [DummyChef].[dbo].[Log] ([UserName],[Password],[Nume],[Prenume],[email],[TipCont],[Raspuns]) VALUES(:1,:2,:3,:4,:5,:6,:7)";

       QSqlQuery qry;

       qry.prepare(sqry);

       qry.bindValue(":1",_username);
       qry.bindValue(":2",_password);
       qry.bindValue(":3",_lastname);
       qry.bindValue(":4",_firstname);
       qry.bindValue(":5",_email);
       qry.bindValue(":6",_account);
       qry.bindValue(":7",_answer);

       qry.exec();
       message.append("inregistrare cu succes");
       message.append(delim);
       db.close();
   }
   else
   {
       try
       {
           BD_exception ex;
           throw ex;
       }
       catch(IExceptions &ex)
       {
           //trimit eroarea
       }
   }

return message;
}


