#include "document_favorite.h"
#include <QtSql>
#include "iexceptions.h"
#include "bd_exception.h"


