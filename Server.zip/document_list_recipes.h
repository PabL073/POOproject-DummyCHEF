#ifndef DOCUMENT_LIST_RECIPES_H
#define DOCUMENT_LIST_RECIPES_H

#include "idocument.h"

class Document_List_Recipes : public IDocument
{
private:
    QString _keyword;
    int _col0;
    int _col1;
public:
    Document_List_Recipes(QString keyword,int col0, int col1) :_keyword(keyword), _col0(col0), _col1(col1) {};
    QString Message();
};

#endif // DOCUMENT_LIST_RECIPES_H
