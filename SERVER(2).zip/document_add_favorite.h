#ifndef DOCUMENT_ADD_FAVORITE_H
#define DOCUMENT_ADD_FAVORITE_H

#include "document.h"

class Document_Add_Favorite : public document
{
private:
    QString _username;
    QString _recipe;
    QString _chef_name;
public:
    Document_Add_Favorite(QString str)
    {
        QString delim="/";
        _username=str.section(delim,1,1);
        _recipe=str.section(delim,2,2);
        _chef_name=str.section(delim,3,3);
    }
    QString Message()override;
};

#endif // DOCUMENT_ADD_FAVORITE_H
