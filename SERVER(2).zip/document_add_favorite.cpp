#include "document_add_favorite.h"
#include <QtSql>
#include "iexceptions.h"
#include "bd_exception.h"


QString Document_Add_Favorite::Message()
{

    QString delim="/";

    QString servername ="DESKTOP-V7ILIT2";
    QString dbname="DummyChef";
    QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");
    db.setConnectOptions();
    QString dsn = QString ("DRIVER={SQL SERVER};SERVER=%1;DATABASE=%2;Trusted_Connection=Yes;").arg(servername).arg(dbname);
    db.setDatabaseName(dsn);
    QString message="11";
    message.append(delim);
       if(db.open())
       {
           QSqlQuery qry;
           if(qry.exec("SELECT Retete.IdReteta from [DummyChef].[dbo].[Retete] where Retete.Denumire_reteta='Paste cu pui' and Retete.Nume_chef='Popescu Florin'"))
           {
               while(qry.next())
               {
               int idRecipe=qry.value(0).toInt();
               qry.prepare("INSERT INTO [DummyChef].[dbo].[Favorite] (Username,IdReteta) VALUES (:username,:id)");
               qry.bindValue(":username",this->_username);
               qry.bindValue(":id",idRecipe);
               if(qry.exec())
               {
                  message.append("reteta a fost adugata cu succes in lista de favorite/");
               }

               else
               {
                   //eroare
               }
               }
           }
           else
           qDebug()<<"Eroare";

           db.close();
       }
       else
       {
           try
           {
               BD_exception ex;
               throw ex;
           }
           catch(IExceptions &ex)
           {
               //trimit eroarea
           }
       }

    return message;
}

