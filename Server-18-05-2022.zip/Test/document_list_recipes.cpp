#include "document_list_recipes.h"

#include <QtSql>
#include <QSqlError>
#include "iexceptions.h"
#include "bd_exception.h"


QString Document_List_Recipes::Message()
{
    QSqlDatabase db=this->open_DB();
    QString message;

   if(db.open())
   {
       QString delim="/";
       message="5/";
       int ok=0;
       QSqlQuery qry;
       if(qry.exec("SELECT [Denumire_reteta],[Nume_chef] FROM [DummyChef].[dbo].[Retete]"))
       {
           while(qry.next())
           {
               if(qry.value(this->_col0).toString().contains(_keyword))
               {
                 if(this->_col0==0)
                 {
                 message.append(qry.value(this->_col0).toString());
                 message.append(delim);
                 }
                 message.append(qry.value(this->_col1).toString());
                 message.append(delim);
                 ok=1;
               }
           }

       if(ok==0)
       {
           if(this->_col0==0)
           message.append("nu exista nicio reteta cu denumirea introdusa/");
                   else
               message.append("nu exista acest chef/");
       }

      }
       else
       {
           try
           {
               IExceptions *ex=Factory_Exceptions::Create_BD_Exception_Instance();
               throw ex;
           }
           catch(IExceptions &ex)
           {
               message.append(ex.Message());
           }
       }
       db.close();
  }
   else
   {
       try
       {
           IExceptions *ex=Factory_Exceptions::Create_BD_Exception_Instance();
           throw ex;
       }
       catch(IExceptions &ex)
       {
           message.append(ex.Message());
       }
   }
return message;
}
