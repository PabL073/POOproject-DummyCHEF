#ifndef DOCUMENT_ADD_RECIPE_H
#define DOCUMENT_ADD_RECIPE_H

#include "document.h"

class Document_add_recipe : public document
{
public:
    Document_add_recipe();
};

#endif // DOCUMENT_ADD_RECIPE_H
