#include "idocument.h"
#include "document_log.h"
#include "document_uniqueuser.h"
#include "document_register.h"
#include "document_passwordreset.h"
#include "document_list_recipes.h"

IDocument* Factory_Document::Create_LogInstance(const QString& username, const QString& password)
{
    return new Document_Log(username, password);
};

IDocument* Factory_Document::Create_UniqueUserInstance(const QString& username)
{
    return new Document_UniqueUser(username);
}

IDocument* Factory_Document::Create_RegisterInstance(const QString& lastname,const QString& firstname,const QString& email, const QString& username,const QString& password,const QString& account,const QString& answer)
{
    return new Document_Register(lastname,firstname,email,username,password,account,answer);
}

IDocument* Factory_Document::Create_PasswordResetInstance(const QString& username,const QString& answer,const QString& newpassword)
{
    return  new Document_PasswordReset(username,answer,newpassword);
}

IDocument* Factory_Document::Create_ListRecipesInstance(const QString& keyword,int col0, int col1)
{
    return  new Document_List_Recipes(keyword,col0,col1);
}
