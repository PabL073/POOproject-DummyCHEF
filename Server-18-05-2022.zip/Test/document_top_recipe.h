#ifndef DOCUMENT_TOP_RECIPE_H
#define DOCUMENT_TOP_RECIPE_H

#include "document.h"

class Document_Top_Recipe : public document
{
public:
    Document_Top_Recipe(){};
    QString Message();
};

#endif // DOCUMENT_TOP_RECIPE_H
