#include <QCoreApplication>
#include <QTcpServer>
#include <QThread>
#include<iostream>
#include <QtSql>
#include <QSqlError>
#include "server.h"
#include"idocument.h"


using namespace std;



int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    //Server myServer;
    //myServer.StartServer();


    QString str="4/cart/";
    //str=QString(Data);
    QString index=str[0];
    int prot;
    prot=index.toInt();
    index="/";
    IDocument * pdocument;
    QString send;

    switch(prot)
    {
    case(LOGARE):
    {
        QString username=str.section(index,1,1);
        QString password=str.section(index,2,2);
        pdocument = Factory_Document::Create_LogInstance(username, password);
        send=pdocument->Message();
        qDebug()<<send;
        break;
    }
    case(VERIF_USER_UNIC):
    {
        QString username=str.section(index,1,1);
        pdocument = Factory_Document::Create_UniqueUserInstance(username);
        send=pdocument->Message();
        qDebug()<<send;
        break;
    }
    case(REGISTER):
    {
        QString lastname=str.section(index,1,1);
        QString firstname=str.section(index,2,2);
        QString email=str.section(index,3,3);
        QString username=str.section(index,4,4);
        QString password=str.section(index,5,5);
        QString account=str.section(index,6,6);
        QString answer=str.section(index,7,7);
        pdocument = Factory_Document::Create_RegisterInstance(lastname,firstname,email,username,password,account,answer);
        send=pdocument->Message();
        qDebug()<<send;
        break;
    }
    case(PASSWORD_RESET):
    {
        QString username=str.section(index,1,1);
        QString answer=str.section(index,2,2);
        QString newpassword=str.section(index,3,3);
        pdocument = Factory_Document::Create_PasswordResetInstance(username,answer,newpassword);
        send=pdocument->Message();
        qDebug()<<send;
        break;
    }
    case(LISTA_DENUMIRI_RETETE):
    {
        QString keyword=str.section(index,1,1);
        pdocument = Factory_Document::Create_ListRecipesInstance(keyword,0,1);
        send=pdocument->Message();
        qDebug()<<send;
        break;
    }
    case(LISTA_RETETE_CHEFI):
    {
        QString keyword=str.section(index,1,1);
        pdocument = Factory_Document::Create_ListRecipesInstance(keyword,1,0);
        send=pdocument->Message();
        qDebug()<<send;
        break;
    }
    default:
    {
        try
        {
           Protocol_exception ex;
           throw ex;
        }
        catch(IExceptions &ex)
        {
            //trimit eroarea
        }
        break;
    }
    }

    return a.exec();
}
