#ifndef SHOWRETETA_H
#define SHOWRETETA_H

#include <QWidget>

namespace Ui {
class showReteta;
}

class showReteta : public QWidget
{
    Q_OBJECT

public:
    explicit showReteta(QWidget *parent = nullptr);
    ~showReteta();
    void completeTitlu(QString s);
    void completeIngrediente(QStringList s);
    void completeDescriere(QString s);
    void completeNota(QString s);
    void completeRecenzii(QStringList s);


private slots:
    void on_pushButton_clicked();

    void on_addNota_editingFinished();

    void on_addReview_clicked();

    void on_reviewTEXT_textChanged();

private:
    Ui::showReteta *ui;
};

#endif // SHOWRETETA_H
