#ifndef IEXCEPTIONS_FACTORY_H
#define IEXCEPTIONS_FACTORY_H


class iexceptions_factory
{
public:
    iexceptions_factory();
};

#endif // IEXCEPTIONS_FACTORY_H
