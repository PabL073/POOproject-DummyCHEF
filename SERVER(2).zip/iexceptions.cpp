#include "iexceptions.h"

IExceptions::IExceptions()
{

}
