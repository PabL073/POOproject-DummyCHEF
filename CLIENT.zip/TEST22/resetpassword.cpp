#include "resetpassword.h"
#include "ui_resetpassword.h"
#include "ui_login.h"
#include <QString>
#include "tcpclient.h"


resetPassword::resetPassword(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::resetPassword)
{
    ui->setupUi(this);
    ui->restrictiiParola->setVisible(false);
}

resetPassword::~resetPassword()
{
    delete ui;
}

void resetPassword::on_sendAnswerButtomn_clicked()
{
    QString data="3/"+TCPClient::getUsername()+"/";
    delete this;
}

